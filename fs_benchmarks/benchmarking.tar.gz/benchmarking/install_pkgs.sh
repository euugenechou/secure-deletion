#!/bin/sh

apt install make gcc bonnie++ trousers libdevmapper-dev libcurl4-openssl-dev libtspi-dev tpm-tools -y --force-yes

