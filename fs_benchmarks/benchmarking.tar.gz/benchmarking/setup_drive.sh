#!/bin/sh

if [ $(id -u) -ne 0 ]; then
    echo "Must run as root!"
    exit 0
fi

echo "[*] Running debootstrap..."
debootstrap jessie jessie
echo "[*] debootsrap finished!"

echo "[*] Setting blank root password..."
sed -i '/^root/ { s/:x:/::/ }' jessie/etc/passwd
echo "[*] Finished!"
echo "[*] Creating disk image..."
dd if=/dev/zero of=benchmark.img bs=1 seek=4GB count=1
mkfs.ext4 -F benchmark.img
echo "[*] Finished!"
echo "[*] Mounting disk image and copying files..."
mkdir -p /mnt/benchmark
mount -o loop benchmark.img /mnt/benchmark/
cp -a jessie/. /mnt/benchmark/
cp install_pkgs_setup_volume.sh /mnt/benchmark/root
cp -r eraser-userland /mnt/benchmark/root
cp -r holepunch-userland /mnt/benchmark/root
cp *.ko /mnt/benchmark/root
cp -r scripts /mnt/benchmark/root
echo "[*] Done copying files!"
rm -r jessie
echo "[*] Chrooting and installing packages"
chroot /mnt/benchmark/ /bin/bash -c "apt install dhcpcd5 -y --force-yes"
echo "[*] Leaving chroot jail!"
umount /mnt/benchmark
chmod 766 benchmark.img


