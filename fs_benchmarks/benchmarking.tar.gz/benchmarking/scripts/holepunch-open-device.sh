#!/bin/bash

insmod /root/dm-holepunch.ko
printf "ooo\no" | holepunch open /dev/sdb1 test
mount /dev/mapper/holepunch /mnt/home
