#!/bin/bash

insmod /root/dm-eraser.ko
printf "ooo\no\no" | eraser create /dev/sdb1 5
printf "ooo\no" | eraser open /dev/sdb1 test
mkfs.ext4 /dev/mapper/eraser
mount /dev/mapper/eraser /mnt/home
