#!/bin/bash

umount /mnt/home
eraser close test
rmmod dm_eraser

