#!/bin/bash

insmod /root/dm-eraser.ko
printf "ooo\no" | eraser open /dev/sdb1 test
mount /dev/mapper/eraser /mnt/home
