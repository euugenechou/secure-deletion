#!/bin/bash

insmod /root/dm-holepunch.ko
printf "ooo\no\no" | holepunch create /dev/sdb1 5
printf "ooo\no" | holepunch open /dev/sdb1 test
mkfs.ext4 /dev/mapper/holepunch
mount /dev/mapper/holepunch /mnt/home
