#!/bin/bash

umount /mnt/home
holepunch close test
rmmod dm_holepunch

