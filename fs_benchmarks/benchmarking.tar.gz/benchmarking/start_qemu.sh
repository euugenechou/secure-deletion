#!/bin/sh

mkdir -p /tmp/emulated_tpm
swtpm_setup \
    --overwrite \
    --tpmstate /tmp/emulated_tpm

swtpm socket \
    --tpmstate dir=/tmp/emulated_tpm \
    --ctrl type=unixio,path=/tmp/emulated_tpm/swtpm-sock \
    --log level=20 \
    -d

qemu-system-x86_64 \
    -m 2G \
    -cpu host \
    --enable-kvm \
    -kernel bzImage \
    -drive file=benchmark.img,index=0,media=disk,format=raw \
    -drive file=encrypted.img,index=1,media=disk,format=raw \
    -net nic, -net user \
    -chardev socket,id=chrtpm,path=/tmp/emulated_tpm/swtpm-sock \
    -tpmdev emulator,id=tpm0,chardev=chrtpm \
    -device tpm-tis,tpmdev=tpm0 \
    -nographic \
    -append "console=ttyS0 root=/dev/sda rw"

