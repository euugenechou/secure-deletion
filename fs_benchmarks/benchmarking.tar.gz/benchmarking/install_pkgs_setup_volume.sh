#!/bin/bash

apt install make gcc bonnie++ trousers libdevmapper-dev libcurl4-openssl-dev libtspi-dev tpm-tools -y --force-yes
cd holepunch-userland
make install
cd ../eraser-userland
make install
cd ..
printf "n\n\n\n\nw" | fdisk /dev/sdb
mkdir -p /mnt/home
