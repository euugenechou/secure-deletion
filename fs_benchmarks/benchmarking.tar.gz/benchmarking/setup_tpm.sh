#/bin/sh

mkdir -p /tmp/emulated_tpm
swtpm_setup \
    --overwrite \
    --tpmstate /tmp/emulated_tpm

